---
name: Bug report
about: 上报本库存在的BUG，请避免重复，确认已经仔细查看过本库的README和之前的Issues
title: ''
labels: ''
assignees: ''

---

我已经仔细查看过本库的README和之前的Issues，没有发现解决方案。

**问题描述**


**如何复现**


操作系统：

python版本：

HarvestText版本：
