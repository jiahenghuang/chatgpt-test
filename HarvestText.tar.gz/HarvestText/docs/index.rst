.. HarvestText documentation master file, created by
   sphinx-quickstart on Mon Jan 20 14:59:39 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to HarvestText's documentation!
=======================================

本文档目前记录了部分函数的参数含义，具体例子请见项目主页：https://github.com/blmoistawinde/HarvestText

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   harvesttext.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
